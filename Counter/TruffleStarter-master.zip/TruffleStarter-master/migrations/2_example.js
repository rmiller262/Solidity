const Example = artifacts.require('Example')

module.exports = function (deployer) {
  deployer.deploy(Example)
}
